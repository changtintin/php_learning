<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ctrlr01 extends Controller
{

    function square()
    {
        if (isset($_GET['square_input'])) {
            $sq = $_GET['square_input'];
            return view('homepage', [
                'square_output' => pow($sq, 2),
            ]);
        }
    }

    function root()
    {
        if (isset($_GET['root_input'])) {
            $rt = $_GET['root_input'];
            return view('homepage', [
                'root_output' => sqrt($rt),
            ]);
        }
    }

    function prime()
    {
        if (isset($_GET['prime_input'])) {
            $rt = $_GET['prime_input'];
        }
    }
}
