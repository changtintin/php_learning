<style>
   
    html {
        position: relative;
        min-height: 100%;
    }
    
    .header {
        padding: 60px;
        text-align: center;
        background: rgb(197, 202, 150);
        color: rgb(57, 102, 84);
        font-size: 40px;
        font-weight: bolder;
        }
    .div1{
        color:rgb(74, 81, 122);
        background-color: rgb(136, 177, 161);
        height: 500px;
        padding: 20px;
        font-size: 30px;
        margin-bottom: 200px;
    }
    footer{
        text-align: center;
        color:rgb(195, 195, 195);
        background-color: rgb(70, 89, 95);
        padding: 20px;
        position: absolute;
        bottom: 0;
        width: 100%;
        height: 200px;
        position:fixed;
    }
    body{
        margin: 0px;
        margin-bottom: 200px;
    }
    li{
        list-style: none;
        padding: 10px;
        font-size: 20px;
        font-weight: bold;
    }
    .submit_btn{
        border: none;
        border-radius: 10px;
        padding: 10px;
        font-size: 20px;
        color:rgb(74, 81, 122);    
    }
    .submit_btn:hover{
        background: rgb(161, 123, 123);
    }
    input{
        border: none;
        padding:10px;
    }
    
</style>