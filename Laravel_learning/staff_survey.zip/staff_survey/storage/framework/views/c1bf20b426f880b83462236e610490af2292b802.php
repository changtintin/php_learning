<div style="background-image:url(https://images.unsplash.com/photo-1525193612562-0ec53b0e5d7c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740&q=80);  height: 500px;
background-position: center;background-repeat: no-repeat;background-size: cover;position: relative;">
    <h1>Staff <br>Information</h1>
</div>
<?php $__env->startSection('div'); ?>
    <div class="container">
        <div class="row">
            <div class="col" style="background-color: rgba(165, 134, 99, 0.712);padding:30px;">
                <h2>Fill in your information</h2>
                <p>We sincerely invite you to help us in developing our working envirment.</p>
                <p>This survey will be used in a non-profit way only.</p>
            </div>
            <div class="col-9">
                <form action="<?php echo e(route('survey.create')); ?>">
                    <div class="form-floating mb-4">
                        <input type="text" class="form-control" id="name" name="name" placeholder="__">
                        <label for="name">Name</label>
                    </div>
                    <div class="form-floating mb-4">
                        <input type="email" class="form-control" id="email" name="email" placeholder="__">
                        <label for="email">Email address</label>
                    </div>
                    <div class="form-floating mb-4 ">
                        <input type="text" class="form-control" id="salary" name="salary" placeholder="__">
                        <label for="salary">Salary</label>
                    </div>
                    <div class="form-floating mb-4 ">
                        <input type="text" class="form-control" id="personality" name="personality" placeholder="__">
                        <label for="personality">Personality</label>
                    </div>
                    <input type="submit" value="Submit">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('div2'); ?>
    <h2>The results</h2>
    <table class="table table-striped table-dark">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">First</th>
            <th scope="col">Last</th>
            <th scope="col">Handle</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>Otto</td>
            <td>@mdo</td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>Jacob</td>
            <td>Thornton</td>
            <td>@fat</td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td>Larry</td>
            <td>the Bird</td>
            <td>@twitter</td>
          </tr>
        </tbody>
      </table>
<?php $__env->stopSection(); ?>

    

<?php echo $__env->make('template.temp01', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ting/Desktop/php_learning/Laravel_learning/staff_survey/resources/views/mainpage.blade.php ENDPATH**/ ?>