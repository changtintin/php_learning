<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <?php echo $__env->make('template.css.temp01_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
   
    <h1><?php echo $__env->yieldContent('header_title'); ?></h1>
    
    <div class="content">
        <?php echo $__env->yieldContent('div'); ?>
    </div>
    <div class="show">
        <?php echo $__env->yieldContent('div2'); ?>
    </div>
    
    <footer>
        <?php $__env->startSection('ft'); ?>
            <h3>Well Done</h3>
            <p>made by Tintin Chang</p>
            <p>tin871001@fk.com</p>
            <p>Instagram/Facebook: changtintin</p>
        <?php echo $__env->yieldSection(); ?>
    </footer>
</body>
</html><?php /**PATH /Users/ting/Desktop/php_learning/Laravel_learning/staff_survey/resources/views/template/temp01.blade.php ENDPATH**/ ?>