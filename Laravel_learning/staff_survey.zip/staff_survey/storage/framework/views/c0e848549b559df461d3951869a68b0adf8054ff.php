<style>
    h1{
       position: absolute;
       top: 50%;
       left: 50%;
       transform: translate(-50%, -50%);
       color: rgb(238, 233, 228);
       font-size:200px;
       text-align: center;
       opacity: 0.7;">

    }
    .content{
        padding:80px;
        margin: none;
        height: 500px;
        background-color: rgb(109, 100, 88);
    }
    .show{
        padding:80px;
        margin: none;
        height: 700px;
        background-color: rgb(113, 129, 124);
    }
    footer{
        margin: none;
        height: auto;
        background-color: rgb(197, 175, 147);
        text-align: center;
        color:rgb(114, 92, 92);
        padding: 20px;
        bottom: 0;
        width: 100%;
        position: relative;    
    }
</style><?php /**PATH /Users/ting/Desktop/php_learning/Laravel_learning/staff_survey/resources/views/template/css/temp01_css.blade.php ENDPATH**/ ?>